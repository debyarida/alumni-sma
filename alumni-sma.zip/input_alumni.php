<?php include 'header2.php'; ?>
		
<!DOCTYPE html>
<html>
  <head>
    

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <!--
  BODY TAG OPTIONS:
  =================
  Apply one or more of the following classes to get the
  desired effect
  |---------------------------------------------------------|
  | SKINS         | skin-blue                               |
  |               | skin-black                              |
  |               | skin-purple                             |
  |               | skin-yellow                             |
  |               | skin-red                                |
  |               | skin-green                              |
  |---------------------------------------------------------|
  |LAYOUT OPTIONS | fixed                                   |
  |               | layout-boxed                            |
  |               | layout-top-nav                          |
  |               | sidebar-collapse                        |
  |               | sidebar-mini                            |
  |---------------------------------------------------------|
  -->
 
         <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Inputan Event</h3>
                </div><!-- /.box-header -->
				<br>
			    <br>
				<br>
				<br>
				<br>
                <form class="form-horizontal" action="simpan_alumni.php" method="post" required>  
        						<div class="form-group">
                      <label class="control-label col-xs-3" for="input_alumni">No Induk:</label>
                      <div class="col-xs-3">
                      <input type="text" class="form-control" name="no_induk" maxlength="5" required>
                      </div>
                    </div>
                    <div class="form-group">
        						  <label class="control-label col-xs-3" for="input_alumni">Nama:</label>
        						  <div class="col-xs-3">
        							<input type="text" class="form-control" name="nama" maxlength="30" required>
        						  </div>
        						</div>      						
      							<div class="form-group">
        						  <label class="control-label col-xs-3" for="input_alumni">Alamat:</label>
        						  <div class="col-xs-3">
        							<input type="text" class="form-control" name="alamat" maxlength="50" required>
        						  </div>
        						</div>
      							<div class="form-group">
        						  <label class="control-label col-xs-3" for="input_alumni">Tahun Masuk:</label>
        						  <div class="col-xs-3">
        							<input type="text" class="form-control" name="thn_masuk" maxlength="4" required>
        						  </div>
        						</div>
      							<div class="form-group">
        						  <label class="control-label col-xs-3" for="input_alumni">Jurusan:</label>
        						  <div class="col-xs-3">
        							<input type="text" class="form-control" name="jurusan" maxlength="20" required>
        						  </div>
        						</div>
                    <div class="form-group">
                      <label class="control-label col-xs-3" for="input_alumni">Tahun Lulus:</label>
                      <div class="col-xs-3">
                      <input type="text" class="form-control" name="thn_lulus" maxlength="4" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-xs-3" for="input_alumni">No HP:</label>
                      <div class="col-xs-3">
                      <input type="text" class="form-control" name="no_hp" maxlength="12" required>
                      </div>
                    </div>
        						<div class="form-group">
        						  <div class="col-xs-offset-3 col-xs-9">
        							<input type="submit" name="Input" class="btn btn-default" value="Simpan">
        							<input type="reset" name="reset" class="btn btn-default" value="Reset"> &nbsp;&nbsp;
        						  </div>
        						</div>
      					</form>

						<br>
						<br>
						<br>
						<br>
						<br>
						<br>
						<br>
						
                </div><!-- /.box-body -->
              </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

     
    <!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 2.1.4 -->
    <script src="dist/js/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="dist/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <?php if (isset($_GET['no_induk'])) { ?>
       <script>alert("No Induk Siswa : <?=$_GET['no_induk']?> Sudah Ada");</script>
    <?php } ?>
    <!-- Optionally, you can add Slimscroll and FastClick plugins.
          Both of these plugins are recommended to enhance the
          user experience. Slimscroll is required when using the
          fixed layout. -->
  </body>
</html>
		
<?php include 'footer.php'; ?>
	