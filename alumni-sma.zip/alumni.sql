-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2016 at 02:28 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `alumni`
--

-- --------------------------------------------------------

--
-- Table structure for table `input_alumni`
--

CREATE TABLE IF NOT EXISTS `input_alumni` (
  `no_induk` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `thn_masuk` int(10) NOT NULL,
  `jurusan` varchar(10) NOT NULL,
  `thn_lulus` int(10) NOT NULL,
  `no_hp` int(20) NOT NULL,
  PRIMARY KEY (`no_induk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `input_alumni`
--

INSERT INTO `input_alumni` (`no_induk`, `nama`, `alamat`, `thn_masuk`, `jurusan`, `thn_lulus`, `no_hp`) VALUES
('001', 'linda', 'smg', 2009, 'ipa', 2012, 0);

-- --------------------------------------------------------

--
-- Table structure for table `input_event`
--

CREATE TABLE IF NOT EXISTS `input_event` (
  `id` varchar(30) NOT NULL,
  `kegiatan` varchar(50) NOT NULL,
  `hari` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time(6) NOT NULL,
  `tempat` varchar(50) NOT NULL,
  `file` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trlsm`
--

CREATE TABLE IF NOT EXISTS `trlsm` (
  `NIMHSTRLSM` char(20) DEFAULT NULL,
  `NMMHSTRLSM` char(50) DEFAULT NULL,
  `TPLHRTRLSM` char(40) DEFAULT NULL,
  `TGLHRTRLSM` date DEFAULT NULL,
  `KDJEKTRLSM` int(11) DEFAULT NULL,
  `TGMSKTRLSM` date DEFAULT NULL,
  `TGLLSTRLSM` date DEFAULT NULL,
  `LLSKETRLSM` int(11) DEFAULT NULL,
  `NLIPKTRLSM` decimal(4,2) DEFAULT NULL,
  `THSTDTRLSM` int(11) DEFAULT NULL,
  `BLSTDTRLSM` int(11) DEFAULT NULL,
  `HRSTDTRLSM` int(11) DEFAULT NULL,
  `NMORTTRLSM` char(50) DEFAULT NULL,
  `ALAMTRLSM` char(80) DEFAULT NULL,
  `KDKOTTRLSM` char(3) DEFAULT NULL,
  `KDPROTRLSM` char(2) DEFAULT NULL,
  `NOTELTRLSM` char(15) DEFAULT NULL,
  `NOHPETRLSM` char(15) DEFAULT NULL,
  `SKRIPTRLSM` char(254) DEFAULT NULL,
  `PEMB1TRLSM` char(50) DEFAULT NULL,
  `PEMB2TRLSM` char(50) DEFAULT NULL,
  `PHOTOTRLSM` char(40) DEFAULT NULL,
  `WSDKETRLSM` char(3) DEFAULT NULL,
  `WSDTHTRLSM` char(4) DEFAULT NULL,
  `PREDITRLSM` int(11) DEFAULT NULL,
  `SKRETTRLSM` char(20) DEFAULT NULL,
  `TGRETTRLSM` datetime DEFAULT NULL,
  `NOIJFTRLSM` char(30) DEFAULT NULL,
  `NOIJUTRLSM` char(30) DEFAULT NULL,
  `TOEFLTRLSM` int(11) DEFAULT NULL,
  `KURSITRLSM` char(4) DEFAULT NULL,
  `KDPSTTRLSM` char(3) DEFAULT NULL,
  `KDJENTRLSM` char(1) DEFAULT NULL,
  `JCUTITRLSM` int(11) DEFAULT NULL,
  `STWSDTRLSM` char(1) DEFAULT NULL,
  `THP1` char(1) DEFAULT NULL,
  `THP2` char(1) DEFAULT NULL,
  `THP3` char(2) DEFAULT NULL,
  `THP4` char(3) DEFAULT NULL,
  `KESANTRLSM` char(250) DEFAULT NULL,
  `TAHUNMSMHS` char(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trlsm`
--

INSERT INTO `trlsm` (`NIMHSTRLSM`, `NMMHSTRLSM`, `TPLHRTRLSM`, `TGLHRTRLSM`, `KDJEKTRLSM`, `TGMSKTRLSM`, `TGLLSTRLSM`, `LLSKETRLSM`, `NLIPKTRLSM`, `THSTDTRLSM`, `BLSTDTRLSM`, `HRSTDTRLSM`, `NMORTTRLSM`, `ALAMTRLSM`, `KDKOTTRLSM`, `KDPROTRLSM`, `NOTELTRLSM`, `NOHPETRLSM`, `SKRIPTRLSM`, `PEMB1TRLSM`, `PEMB2TRLSM`, `PHOTOTRLSM`, `WSDKETRLSM`, `WSDTHTRLSM`, `PREDITRLSM`, `SKRETTRLSM`, `TGRETTRLSM`, `NOIJFTRLSM`, `NOIJUTRLSM`, `TOEFLTRLSM`, `KURSITRLSM`, `KDPSTTRLSM`, `KDJENTRLSM`, `JCUTITRLSM`, `STWSDTRLSM`, `THP1`, `THP2`, `THP3`, `THP4`, `KESANTRLSM`, `TAHUNMSMHS`) VALUES
('nadia', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(NULL, 'nadia', NULL, NULL, NULL, NULL, NULL, 2009, NULL, NULL, NULL, NULL, NULL, 'jl. kauman timur II/113', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'fika', '12345'),
(2, 'nadia', '12345'),
(3, 'dalfin', '12345');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
