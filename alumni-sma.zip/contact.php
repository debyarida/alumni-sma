<?php require_once 'koneksi.php';?>
<?php include 'header1.php'; ?>
		
<!-- ==== CONTACT ==== -->
		<!--<section class="section-divider textdivider divider10" id="Contact" name="Contact">-->
		<div class="container" id="Contact" name="Contact">
			<div class="row centered">
			<br>
			<br>
			<br>
				<span class="icon-phone-3" style="font-size:80px;"></span>
				<h1 class="centered">CONTACT</h1>
				<hr>
				<br>
				<br>
				<div>
					<h3>Contact Information</h3>
					<p> <span class="icon icon-home"></span> Jl. Pemuda Gg Suromenggalan 62 Semarang<br/>
						<span class="icon icon-phone"></span> (024) 3546864 <br/>
						</br>
						Ketua Panitia</br>
						Sekretaris</br>
						Bendahara</br>
						</br>
						</br>
					</p>
				</div><!-- col -->
					
		</div><!-- container -->
				
		</div><!-- row -->
		
<?php include 'footer.php'; ?>
