<?php

require_once ('Aksi.php');
			$aksi = new Aksi();
			
			$id				= $_POST['id'];
            $kegiatan		= $_POST['kegiatan'];
            $hari 			= $_POST['hari'];
			$tanggal		= $_POST['tanggal'];
            $tempat 		= $_POST['tempat'];
			$jam			= $_POST['jam'];
            $file 			= $_POST['file'];

            $add = $aksi->addEvent($id, $kegiatan, $hari, $tanggal, $tempat, $jam, $file);
 ?>

 <br/>
<script language="JavaScript">
document.location=('home_admin.php')</script>