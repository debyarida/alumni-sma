		
		<div id="footerwrap">
			<div class="container">
				<h4>Created by <a>DLN-UDINUS</a> - Copyright 2016</h4>
			</div>
		</div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
		

	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/js/retina.js"></script>
	<script type="text/javascript" src="assets/js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="assets/js/smoothscroll.js"></script>
	<script type="text/javascript" src="assets/js/jquery-func.js"></script>
	<script type="text/javascript">
		/*smoothScroll.init({
			selector: '.smoothScroll',
			offset: 0, // Integer. How far to offset the scrolling anchor location in pixels
			callback: function ( toggle, anchor ) {
				
			}
		});*/
	</script>
  </body>
</html>
