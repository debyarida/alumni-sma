<?php include 'header1.php'; ?>

<!-- ==== HEADERWRAP ==== -->
		<div class="row white centered">
			<header class="container" id="Home">
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
					<br>
						<span class="icon-stack" style="font-size:80px;"></span>
						<h1 class="centered">PORTAL ALUMNI</h1>
						<p>SD Islam Sultan Agung 01 Semarang</p>
					<br>
					<br>
					<br>
					<br>
			</header>
			
	    </div><!-- /headerwrap -->
		</br></br></br>
		
<?php include 'footer.php'; ?>	
  		
